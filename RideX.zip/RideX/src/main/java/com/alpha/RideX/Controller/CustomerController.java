package com.alpha.RideX.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alpha.RideX.Entity.Customer;
import com.alpha.RideX.ResponseStructure;
import com.alpha.RideX.Service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/profile")
    public ResponseStructure<Customer> getCustomer(@RequestParam long mobileNo) {
        return customerService.findCustomer(mobileNo);
    }

    @DeleteMapping("/delete")
    public ResponseStructure<Customer> deleteCustomer(@RequestParam long mobileNo) {
        return customerService.deleteCustomerBymbno(mobileNo);
    }

    @PutMapping("/update")
    public ResponseStructure<Customer> updateCustomer(@RequestBody com.alpha.RideX.DTO.CustomerDTO dto) {
        return customerService.updateCustomerProfile(dto);
    }
}
