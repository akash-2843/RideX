package com.alpha.RideX.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.alpha.RideX.ResponseStructure;
import com.alpha.RideX.DTO.RegDriverVehicleDTO;
import com.alpha.RideX.Entity.Driver;
import com.alpha.RideX.Entity.Vechile;
import com.alpha.RideX.Exception.DriverNOtFoundWiththismobileNO;
import com.alpha.RideX.Repository.DriverRepository;
import com.alpha.RideX.Repository.UserRepository;
import com.alpha.RideX.Repository.VechileRepository;
import com.alpha.RideX.Entity.User;
import com.alpha.RideX.Entity.Role;

@Service
public class DriverService {

	@Autowired
	private DriverRepository driverrepo;

	@Autowired
	private LocationService locationService;

	@Autowired
	private VechileRepository vehiclerepo;

	@Autowired
	private org.springframework.security.crypto.password.PasswordEncoder passwordEncoder;

	@Autowired
	private UserRepository userRepo;

	// saveregDriver
	public ResponseStructure<Driver> saveRegDriver(RegDriverVehicleDTO dto) {

		// Fetch city using LocationService
		String city;
		if (dto.getLocationName() != null && !dto.getLocationName().isEmpty()) {
			city = dto.getLocationName();
		} else {
			city = locationService.getCityFromCoordinates(dto.getLatitude(), dto.getLongitude());
		}

		if (userRepo.findByMobno(dto.getMobileNo()) != null) {
			throw new RuntimeException("User with this mobile number already exists.");
		}

		User user = new User();
		user.setMobno(dto.getMobileNo());
		// Encode password before saving
		user.setPassword(passwordEncoder.encode(dto.getPassword()));
		user.setRole(Role.DRIVER);

		Driver driver = new Driver();
		driver.setUser(user);
		driver.setLicenseNo(dto.getLicenceNo());
		driver.setName(dto.getName());
		driver.setAge(dto.getAge());
		driver.setMailid(dto.getMail());
		driver.setGender(dto.getGender());
		driver.setMobno(dto.getMobileNo());
		driver.setUpiid(dto.getUpiId());
		driver.setStatus("Available");

		Vechile vehicle = new Vechile();

		vehicle.setDriver(driver);

		vehicle.setVname(dto.getVehicleName());
		vehicle.setVno(dto.getVehicleNo());
		vehicle.setVtype(dto.getType());
		vehicle.setModel(dto.getModel());
		vehicle.setCapacity(dto.getCapacity());
		vehicle.setCurrentcity(city);
		vehicle.setAvailablestatus("Available");
		vehicle.setPriceperkm(dto.getPricePerKm());
		vehicle.setAveragespeed(dto.getAverageSpeed());

		driver.setV(vehicle);

		driverrepo.save(driver);

		ResponseStructure<Driver> resp = new ResponseStructure<>();
		resp.setStatusCode(HttpStatus.CREATED.value());
		resp.setMessage("Driver & Vehicle saved successfully");
		resp.setData(driver);

		return resp;
	}

	// findDriver
	public ResponseStructure<Driver> findDriver(long mobileNo) {
		Driver driver = driverrepo.findBymobno(mobileNo);
		if (driver == null) {
			throw new DriverNOtFoundWiththismobileNO("Driver with" + " " + mobileNo + " " + "not found");
		}

		ResponseStructure<Driver> rs = new ResponseStructure<Driver>();

		rs.setStatusCode(HttpStatus.FOUND.value());
		rs.setMessage("Driver with mobileNo " + mobileNo + "found succesfully");
		rs.setData(driver);
		return rs;
	}

	// updatedriver
	public ResponseStructure<Driver> updateDriver(double lattitude, double longitude, Long mobilenumber) {

		Driver driver = driverrepo.findBymobno(mobilenumber);

		if (driver == null) {
			throw new DriverNOtFoundWiththismobileNO("Driver with" + " " + mobilenumber + " " + "not found");
		}

		String city = locationService.getCityFromCoordinates(lattitude, longitude);
		Vechile v = driver.getV();
		v.setCurrentcity(city);
		driver.setV(v);
		driverrepo.save(driver);

		ResponseStructure<Driver> Rs = new ResponseStructure();
		Rs.setStatusCode(HttpStatus.ACCEPTED.value());
		Rs.setMessage("Location updated");
		Rs.setData(driver);
		return Rs;
	}

	// delete_driver
	public ResponseStructure<Driver> deleteById(long mobileNo) {
		Driver driver = driverrepo.findBymobno(mobileNo);
		if (driver == null) {
			throw new DriverNOtFoundWiththismobileNO("Driver with " + mobileNo + " not found");
		}
		driverrepo.delete(driver);
		ResponseStructure<Driver> rs = new ResponseStructure<Driver>();
		rs.setData(driver);
		rs.setMessage("deleted successful");
		rs.setStatusCode(HttpStatus.OK.value());
		return rs;
	}

	// Toggle Status
	public ResponseStructure<Driver> toggleDriverStatus(long mobileNo, boolean isOnline) {
		Driver driver = driverrepo.findBymobno(mobileNo);
		if (driver == null) {
			throw new DriverNOtFoundWiththismobileNO("Driver not found");
		}

		if (isOnline) {
			// Check Block Status
			if (driver.getBlockedUntil() != null && driver.getBlockedUntil().isAfter(java.time.LocalDateTime.now())) {
				throw new RuntimeException("You are blocked until " + driver.getBlockedUntil());
			}
			// Unblock if time passed (auto-reset)
			if (driver.getRejectionCount() >= 5) {
				driver.setRejectionCount(0);
				driver.setBlockedUntil(null);
			}
		}

		String newStatus = isOnline ? "Available" : "Offline";
		driver.setStatus(newStatus);

		Vechile v = driver.getV();
		if (v != null) {
			v.setAvailablestatus(newStatus);
			vehiclerepo.save(v);
		}

		driverrepo.save(driver);

		ResponseStructure<Driver> rs = new ResponseStructure<>();
		rs.setStatusCode(HttpStatus.OK.value());
		rs.setMessage("Driver is now " + newStatus);
		rs.setData(driver);
		return rs;
}
}
