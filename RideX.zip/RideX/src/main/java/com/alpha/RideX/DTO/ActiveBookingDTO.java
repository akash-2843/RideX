package com.alpha.RideX.DTO;



public class ActiveBookingDTO {

	private int bookingId;
	private String customername;
	private long customermobileno;
	private String source;
	private String destination;
	private String drivername;
	private String vehicleNo;
	private String status;
	private Double fare;
	private String paymentType;
	private String otp;

	public ActiveBookingDTO() {
		super();
	}

	public ActiveBookingDTO(int bookingId, String customername, long customermobileno, String source,
			String destination, String drivername, String vehicleNo, String status, Double fare, String paymentType,
			String otp) {
		super();
		this.bookingId = bookingId;
		this.customername = customername;
		this.customermobileno = customermobileno;
		this.source = source;
		this.destination = destination;
		this.drivername = drivername;
		this.vehicleNo = vehicleNo;
		this.status = status;
		this.fare = fare;
		this.paymentType = paymentType;
		this.otp = otp;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public long getCustomermobileno() {
		return customermobileno;
	}

	public void setCustomermobileno(long customermobileno) {
		this.customermobileno = customermobileno;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDrivername() {
		return drivername;
	}

	public void setDrivername(String drivername) {
		this.drivername = drivername;
	}

	public String getVehicleNo() {
		return vehicleNo;
	}

	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getFare() {
		return fare;
	}

	public void setFare(Double fare) {
		this.fare = fare;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	@Override
	public String toString() {
		return "ActiveBookingDTO [bookingId=" + bookingId + ", customername=" + customername + ", customermobileno="
				+ customermobileno + ", source=" + source + ", destination=" + destination + ", status=" + status
				+ ", fare=" + fare + ", paymentType=" + paymentType + "]";
	}

}
