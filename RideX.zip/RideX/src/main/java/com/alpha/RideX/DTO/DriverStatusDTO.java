package com.alpha.RideX.DTO;

public class DriverStatusDTO {

	private int driverId;
	private String name;
	private Double earnings;
	private String vechileno;
	private int totalRides;

	private ActiveBookingDTO currentRide;

	public DriverStatusDTO() {
		super();
	}

	public DriverStatusDTO(int driverId, String name, Double earnings, String vechileno, int totalRides,
			ActiveBookingDTO currentRide) {
		super();
		this.driverId = driverId;
		this.name = name;
		this.earnings = earnings;
		this.vechileno = vechileno;
		this.totalRides = totalRides;
		this.currentRide = currentRide;
	}

	public int getDriverId() {
		return driverId;
	}

	public void setDriverId(int i) {
		this.driverId = i;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getEarnings() {
		return earnings;
	}

	public void setEarnings(Double earnings) {
		this.earnings = earnings;
	}

	public String getVechileno() {
		return vechileno;
	}

	public void setVechileno(String vechileno) {
		this.vechileno = vechileno;
	}

	public int getTotalRides() {
		return totalRides;
	}

	public void setTotalRides(int totalRides) {
		this.totalRides = totalRides;
	}

	public ActiveBookingDTO getCurrentRide() {
		return currentRide;
	}

	public void setCurrentRide(ActiveBookingDTO currentRide) {
		this.currentRide = currentRide;
	}

}
