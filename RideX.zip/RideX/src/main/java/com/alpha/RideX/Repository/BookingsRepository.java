package com.alpha.RideX.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.alpha.RideX.Entity.Bookings;

public interface BookingsRepository extends JpaRepository<Bookings, Integer> {

    List<Bookings> findByCust_Mobileno(long mobileno);

    List<Bookings> findByDriver_Mobno(long mobno);

    Optional<Bookings> findTopByCust_MobilenoOrderByBookingDateDesc(long mobileno);

    @Query("SELECT b FROM Bookings b WHERE b.cust.mobileno = :phone AND b.status NOT IN ('COMPLETED', 'CANCELLED', 'REJECTED')")
    Optional<Bookings> findActiveBookingByCustomer(@Param("phone") long phone);

    @Query("SELECT b FROM Bookings b WHERE b.driver.mobno = :phone AND b.status NOT IN ('COMPLETED', 'CANCELLED', 'REJECTED')")
    Optional<Bookings> findActiveBookingByDriver(@Param("phone") long phone);

    @Query("SELECT COALESCE(SUM(b.fare), 0.0) FROM Bookings b WHERE b.driver.mobno = :phone AND b.status = 'COMPLETED'")
    Double calculateDriverEarnings(@Param("phone") long phone);

    @Query("SELECT COUNT(b) FROM Bookings b WHERE b.driver.mobno = :phone AND b.status = 'COMPLETED'")
    Integer countDriverCompletedRides(@Param("phone") long phone);

    // PERFORMANCE OPTIMIZATION: Fetch joins to prevent N+1 queries
    @Query("SELECT b FROM Bookings b " +
            "LEFT JOIN FETCH b.cust " +
            "LEFT JOIN FETCH b.driver d " +
            "LEFT JOIN FETCH d.v " +
            "LEFT JOIN FETCH b.payment " +
            "WHERE b.cust.mobileno = :mobileno " +
            "ORDER BY b.bookingDate DESC")
    List<Bookings> findBookingHistoryByCustomer(@Param("mobileno") long mobileno);

    @Query("SELECT b FROM Bookings b " +
            "LEFT JOIN FETCH b.cust " +
            "LEFT JOIN FETCH b.driver d " +
            "LEFT JOIN FETCH d.v " +
            "LEFT JOIN FETCH b.payment " +
            "WHERE b.driver.mobno = :mobno " +
            "ORDER BY b.bookingDate DESC")
    List<Bookings> findBookingHistoryByDriver(@Param("mobno") long mobno);
}
