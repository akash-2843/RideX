package com.alpha.RideX.Configuration;

import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.security.SignatureException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * This filter catches exceptions from other filters (like
 * JwtAuthenticationFilter)
 * and converts them to proper JSON responses using ResponseStructure format.
 */
@Component
public class FilterExceptionHandler extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        try {
            filterChain.doFilter(request, response);
        } catch (UsernameNotFoundException e) {
            // User not found - redirect to registration
            sendErrorResponse(response, HttpStatus.NOT_FOUND, "User not found. Please register.");
        } catch (ExpiredJwtException e) {
            // Token expired
            sendErrorResponse(response, HttpStatus.UNAUTHORIZED, "Session expired. Please login again.");
        } catch (MalformedJwtException e) {
            // Invalid token format
            sendErrorResponse(response, HttpStatus.UNAUTHORIZED, "Invalid token format.");
        } catch (SignatureException e) {
            // Token signature invalid
            sendErrorResponse(response, HttpStatus.UNAUTHORIZED, "Invalid token signature.");
        } catch (Exception e) {
            // For debugging - log the actual exception
            logger.error("Filter exception: " + e.getClass().getName() + " - " + e.getMessage());

            // Check if it's an auth-related exception
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("jwt")) {
                sendErrorResponse(response, HttpStatus.UNAUTHORIZED, "Authentication failed. Please login again.");
            } else {
                // Let it pass through to be handled elsewhere
                throw e;
            }
        }
    }

    private void sendErrorResponse(HttpServletResponse response, HttpStatus status, String message) throws IOException {
        response.setStatus(status.value());
        response.setContentType("application/json");

        // Build JSON manually to avoid Jackson dependency issues
        String jsonResponse = String.format(
                "{\"statusCode\":%d,\"message\":\"%s\",\"data\":null}",
                status.value(),
                message);

        response.getWriter().write(jsonResponse);
    }
}
