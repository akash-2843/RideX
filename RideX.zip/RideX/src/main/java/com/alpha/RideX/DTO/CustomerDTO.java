package com.alpha.RideX.DTO;

import jakarta.validation.constraints.*;

public class CustomerDTO {

	@NotBlank(message = "Name is required")
	@Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
	private String name;

	@Min(value = 18, message = "Age must be at least 18")
	@Max(value = 100, message = "Age must be less than 100")
	private int age;

	@NotBlank(message = "Gender is required")
	@Pattern(regexp = "^(Male|Female|Other)$", message = "Gender must be Male, Female, or Other")
	private String gender;

	@Min(value = 1000000000L, message = "Mobile number must be 10 digits")
	@Max(value = 9999999999L, message = "Mobile number must be 10 digits")
	private long mobileNo;

	@NotBlank(message = "Email is required")
	@Email(message = "Invalid email format")
	private String email;

	private Double latitude;
	private Double longitude;

	@NotBlank(message = "Password is required")
	@Size(min = 6, max = 50, message = "Password must be between 6 and 50 characters")
	private String password;

	@NotBlank(message = "Location name is required")
	@Size(min = 2, max = 100, message = "Location name must be between 2 and 100 characters")
	private String locationName;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "CustomerDTO [name=" + name + ", age=" + age + ", gender=" + gender + ", mobileNo=" + mobileNo
				+ ", email=" + email + ", latitude=" + latitude + ", longitude=" + longitude + "]";
	}

}
