package com.alpha.RideX.Exception;

public class CustomeralreadyExists extends RuntimeException {

	public CustomeralreadyExists(String message)
	{
		super(message);
	}
}
