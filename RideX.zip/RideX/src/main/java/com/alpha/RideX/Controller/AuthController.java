package com.alpha.RideX.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alpha.RideX.Configuration.JwtUtil;
import com.alpha.RideX.DTO.CustomerDTO;
import com.alpha.RideX.DTO.LoginDTO;
import com.alpha.RideX.DTO.RegDriverVehicleDTO;
import com.alpha.RideX.Entity.Customer;
import com.alpha.RideX.Entity.Driver;
import com.alpha.RideX.Entity.User;
import com.alpha.RideX.Repository.UserRepository;
import com.alpha.RideX.ResponseStructure;
import com.alpha.RideX.Service.DriverService;
import com.alpha.RideX.Service.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private DriverService driverService;

    @Autowired
    private CustomerService customerService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserRepository userRepo;

    @PostMapping("/login")
    public ResponseStructure<String> login(@Valid @RequestBody LoginDTO loginDto) {

        // 0. Manual Check: Does user exist?
        // This is needed so we can return 404 (New User) separate from 401 (Bad Password)
        User user = userRepo.findByMobno(loginDto.getMobileNo());
        if (user == null) {
            throw new UsernameNotFoundException("User not found with mobile: " + loginDto.getMobileNo());
        }

        // 1. Authenticate using Spring Security
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        String.valueOf(loginDto.getMobileNo()),
                        loginDto.getPassword()));

        // 2. Generate Token with Role
        Map<String, Object> claims = new HashMap<>();
        claims.put("role", user.getRole().toString());

        org.springframework.security.core.userdetails.User securityUser = new org.springframework.security.core.userdetails.User(
                String.valueOf(user.getMobno()),
                user.getPassword(),
                new ArrayList<>());

        String token = jwtUtil.generateToken(claims, securityUser);

        // 3. Return Token
        ResponseStructure<String> response = new ResponseStructure<>();
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("Login Successful");
        response.setData(token);

        return response;
    }

    @PostMapping("/register/driver")
    public ResponseStructure<Driver> registerDriver(@Valid @RequestBody RegDriverVehicleDTO dto) {
        return driverService.saveRegDriver(dto);
    }

    @PostMapping("/register/customer")
    public ResponseStructure<Customer> registerCustomer(@Valid @RequestBody CustomerDTO dto) {
        return customerService.registerCustomer(dto);
    }
}
