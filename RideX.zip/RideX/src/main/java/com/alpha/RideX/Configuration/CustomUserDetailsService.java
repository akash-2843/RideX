package com.alpha.RideX.Configuration;

import com.alpha.RideX.Entity.User;
import com.alpha.RideX.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // In our app, 'username' is actually the 'mobile number'
        User user = userRepository.findByMobno(Long.parseLong(username));

        if (user == null) {
            throw new UsernameNotFoundException("User not found with mobile: " + username);
        }

        // Return a Spring Security User object with Role
        List<org.springframework.security.core.GrantedAuthority> authorities = new ArrayList<>();
        authorities
                .add(new org.springframework.security.core.authority.SimpleGrantedAuthority(user.getRole().toString()));

        return new org.springframework.security.core.userdetails.User(
                String.valueOf(user.getMobno()), // Username
                user.getPassword(), // Encoded Password from DB
                authorities // Authorities (Roles)
        );
    }
}
