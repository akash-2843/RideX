package com.alpha.RideX.Entity;

public enum Role {
    CUSTOMER,
    DRIVER
}
