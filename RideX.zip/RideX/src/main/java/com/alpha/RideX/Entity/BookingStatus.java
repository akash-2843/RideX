package com.alpha.RideX.Entity;

public enum BookingStatus {
    SEARCHING,
    CONFIRMED,
    IN_TRIP,
    COMPLETED,
    CANCELLED,
    PENDING_APPROVAL,
    REJECTED
}
