package com.alpha.RideX.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PutMapping;
import com.alpha.RideX.ResponseStructure;
import com.alpha.RideX.DTO.AvailableVehiclesDTO;
import com.alpha.RideX.Entity.Driver;
import com.alpha.RideX.Service.DriverService;
import com.alpha.RideX.Service.CustomerService;

@RestController
@RequestMapping("/driver")
public class DriverController {

	@Autowired
	private DriverService ds;

	@Autowired
	private CustomerService customerService;

	@GetMapping("/profile")
	public ResponseStructure<Driver> getDriver(@RequestParam long mobileNo) {
		return ds.findDriver(mobileNo);
	}

	@PutMapping("/location")
	public ResponseStructure<Driver> updateDriverLocation(@RequestParam double latitude, @RequestParam double longitude,
			@RequestParam Long mobileNo) {
		return ds.updateDriver(latitude, longitude, mobileNo);
	}

	@DeleteMapping("/delete")
	public ResponseStructure<Driver> deleteDriver(@RequestParam long mobileNo) {
		return ds.deleteById(mobileNo);
	}

	@PutMapping("/status")
	public ResponseStructure<Driver> toggleStatus(@RequestParam long mobileNo, @RequestParam boolean isOnline) {
		return ds.toggleDriverStatus(mobileNo, isOnline);
	}

	// GET CUSTOMER BY MOBILENO

	// GET ALL AVAILABLE VECGHILES
	@GetMapping("/available-vehicles")
	public ResponseEntity<ResponseStructure<AvailableVehiclesDTO>> getAvailableVehicles(@RequestParam Long mobileno,
			@RequestParam String destination, @RequestParam String source) {

		ResponseStructure<AvailableVehiclesDTO> response = customerService.getAvailableVehiclesByCity(mobileno,
				destination, source);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
