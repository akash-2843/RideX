package com.alpha.RideX.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.alpha.RideX.Entity.Vechile;

import jakarta.persistence.LockModeType;

public interface VechileRepository extends JpaRepository<Vechile, Integer> {

	List<Vechile> findByCurrentcityIgnoreCaseAndAvailablestatus(String currentCity, String status);

	// Pessimistic lock for booking to prevent race conditions
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	@Query("SELECT v FROM Vechile v WHERE v.id = :id")
	Optional<Vechile> findByIdForUpdate(@Param("id") int id);

}
