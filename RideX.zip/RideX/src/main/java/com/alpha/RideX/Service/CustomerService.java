package com.alpha.RideX.Service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.alpha.RideX.ResponseStructure;
import com.alpha.RideX.DTO.AvailableVehiclesDTO;
import com.alpha.RideX.DTO.CustomerDTO;
import com.alpha.RideX.DTO.VehicledetailsDTO;
import com.alpha.RideX.Entity.Customer;
import com.alpha.RideX.Entity.Vechile;
import com.alpha.RideX.Exception.CustomerNotFoundWithMobile;
import com.alpha.RideX.Exception.CustomeralreadyExists;
import com.alpha.RideX.Exception.VehiclesareNotavilabletoDestinationLocation;
import com.alpha.RideX.Repository.CustomerRepository;
import com.alpha.RideX.Repository.UserRepository;
import com.alpha.RideX.Repository.VechileRepository;
import com.alpha.RideX.Entity.User;
import com.alpha.RideX.Entity.Role;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepo;

    @Autowired
    private LocationService locationService;

    @Autowired
    private VechileRepository vehiclerepo;

    @Autowired
    private MapService mapService;

    @Autowired
    private org.springframework.security.crypto.password.PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private EmailService emailService;

    // RegisterCustomer
    public ResponseStructure<Customer> registerCustomer(CustomerDTO cdto) {

        Customer cust = customerRepo.findByMobileno(cdto.getMobileNo());
        if (cust != null) {
            throw new CustomeralreadyExists("customer with " + cdto.getMobileNo() + " already exists");
        }

        if (userRepo.findByMobno(cdto.getMobileNo()) != null) {
            throw new CustomeralreadyExists("User with mobile " + cdto.getMobileNo() + " already exists");
        }

        User user = new User();
        user.setMobno(cdto.getMobileNo());
        // Encode password
        user.setPassword(passwordEncoder.encode(cdto.getPassword()));
        user.setRole(Role.CUSTOMER);

        Customer customer = new Customer();
        customer.setUser(user);

        customer.setName(cdto.getName());
        customer.setAge(cdto.getAge());
        customer.setGender(cdto.getGender());
        customer.setMobileno(cdto.getMobileNo());
        customer.setMail(cdto.getEmail());

        if (cdto.getLocationName() != null && !cdto.getLocationName().isEmpty()) {
            customer.setCurrentLoc(cdto.getLocationName());
        } else {
            customer.setCurrentLoc(locationService.getCityFromCoordinates(cdto.getLatitude(), cdto.getLongitude()));
        }
        customerRepo.save(customer);

        // Welcome Email service
        String subject = "Welcome to RideX!";
        String body = "Dear " + customer.getName() + ",\n\n" +
                "Thank you for registering with RideX. We are excited to have you on board!\n" +
                "Your registered mobile number is: " + customer.getMobileno() + "\n\n" +
                "Happy Riding,\n" +
                "The RideX Team";

        emailService.sendEmail(customer.getMail(), subject, body);

        ResponseStructure<Customer> rs = new ResponseStructure<Customer>();
        rs.setData(customer);
        rs.setMessage("Customer saved successfully");
        rs.setStatusCode(HttpStatus.CREATED.value());
        return rs;
    }

    // findCustomer
    public ResponseStructure<Customer> findCustomer(long mobileno) {

        Customer cust = customerRepo.findByMobileno(mobileno);
        if (cust == null) {
            throw new CustomerNotFoundWithMobile("customer with " + mobileno + " not found");
        }

        ResponseStructure<Customer> rs = new ResponseStructure<Customer>();

        rs.setStatusCode(HttpStatus.FOUND.value());
        rs.setMessage("customerwith mobileNo " + mobileno + " found succesfully");
        rs.setData(cust);
        return rs;
    }

    // DeletCustomerByMbNo
    public ResponseStructure<Customer> deleteCustomerBymbno(long mobileno) {

        Customer cust = customerRepo.findByMobileno(mobileno);
        if (cust == null) {
            throw new CustomerNotFoundWithMobile("customer with " + mobileno + " not found");
        }

        customerRepo.delete(cust);
        ResponseStructure<Customer> rs = new ResponseStructure<Customer>();
        rs.setData(cust);
        rs.setMessage("delete coustmer by mobno " + mobileno);
        rs.setStatusCode(HttpStatus.CREATED.value());
        return rs;
    }

    // getallAvailableVehicles
    public ResponseStructure<AvailableVehiclesDTO> getAvailableVehiclesByCity(Long mobileno, String destinationLocation,
            String inputSource) {

        Customer c = customerRepo.findByMobileno(mobileno);
        if (c == null) {
            throw new CustomerNotFoundWithMobile("Customer with" + " " + mobileno + " " + "not found");
        }

        // we will get customer location (current city)
        String SourceLocation = (inputSource != null && !inputSource.isEmpty()) ? inputSource : c.getCurrentLoc();

        double calculatedDistance;
        try { // this method will give us latitude and longitude based on city name
            double[] sourceCoords = mapService.getCoordinates(SourceLocation);// customer location
            double[] destCoords = mapService.getCoordinates(destinationLocation);// we will get from request when we
                                                                                 // call allAvailabelvechile method

            // using above 2 coordinates of source and destination this method will
            // calculate distance
            calculatedDistance = mapService.getDistanceInKm(
                    sourceCoords[0], sourceCoords[1],
                    destCoords[0], destCoords[1]);
        } catch (Exception e) {
            throw new RuntimeException("Location Error: " + e.getMessage());
        }

        AvailableVehiclesDTO AVD = new AvailableVehiclesDTO();

        AVD.setC(c);
        AVD.setSourceLocation(SourceLocation);
        AVD.setDistance(calculatedDistance);
        AVD.setDestinationLocation(destinationLocation);

        // empty list to store processed vechile later
        List<VehicledetailsDTO> l = new ArrayList<VehicledetailsDTO>();

        // store vechiles based on filter (sourceloaction/customerlocation)
        List<Vechile> list = vehiclerepo.findByCurrentcityIgnoreCaseAndAvailablestatus(SourceLocation, "Available");

        if (list == null || list.isEmpty()) {
            throw new VehiclesareNotavilabletoDestinationLocation("No vechile availalable in " + SourceLocation);
        }

        // iterate through vechile list and set dto datafilds and calculate fare and
        // time
        for (Vechile vehicle : list) {

            VehicledetailsDTO vd = new VehicledetailsDTO();

            int speed = vehicle.getAveragespeed();
            double price = vehicle.getPriceperkm();

            double fare = price * calculatedDistance;

            double time = calculatedDistance / (double) speed;

            vd.setV(vehicle);
            vd.setFare(fare);
            vd.setEstimationTIme(time);

            // add this to vechiledto list (processed vechiles)
            l.add(vd);

        }

        // add list of availbe vechile to availablevechiledto class
        AVD.setAvailabeVehicles(l);

        ResponseStructure<AvailableVehiclesDTO> rs = new ResponseStructure<AvailableVehiclesDTO>();
        rs.setStatusCode(HttpStatus.ACCEPTED.value());
        rs.setMessage("Available vehicles fetched successfully");
        rs.setData(AVD);
        return rs;
    }

    // Update Customer Profile
    public ResponseStructure<Customer> updateCustomerProfile(CustomerDTO cdto) {
        Customer cust = customerRepo.findByMobileno(cdto.getMobileNo());
        if (cust == null) {
            throw new CustomerNotFoundWithMobile("Customer with mobile " + cdto.getMobileNo() + " not found");
        }

        if (cdto.getName() != null && !cdto.getName().isEmpty())
            cust.setName(cdto.getName());

        if (cdto.getEmail() != null && !cdto.getEmail().isEmpty())
            cust.setMail(cdto.getEmail());

        if (cdto.getAge() > 0)
            cust.setAge(cdto.getAge());

        if (cdto.getGender() != null && !cdto.getGender().isEmpty())
            cust.setGender(cdto.getGender());

        if (cdto.getLocationName() != null && !cdto.getLocationName().isEmpty())
            cust.setCurrentLoc(cdto.getLocationName());

        customerRepo.save(cust);

        ResponseStructure<Customer> rs = new ResponseStructure<>();
        rs.setData(cust);
        rs.setMessage("Profile updated successfully");
        rs.setStatusCode(HttpStatus.OK.value());
        return rs;
    }
}
