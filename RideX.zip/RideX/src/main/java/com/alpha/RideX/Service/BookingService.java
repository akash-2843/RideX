package com.alpha.RideX.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpStatus;

import com.alpha.RideX.ResponseStructure;
import com.alpha.RideX.DTO.ActiveBookingDTO;
import com.alpha.RideX.DTO.BookingRequestDTO;
import com.alpha.RideX.DTO.BookingResponseDTO;
import com.alpha.RideX.DTO.CustomerStatusDTO;
import com.alpha.RideX.DTO.DriverStatusDTO;
import com.alpha.RideX.Entity.*;
import com.alpha.RideX.Exception.CustomerNotFoundWithMobile;
import com.alpha.RideX.Exception.DriverNOtFoundWiththismobileNO;
import com.alpha.RideX.Repository.*;
import com.alpha.RideX.DTO.UpiPaymentDTO;

@Service
public class BookingService {

    @Autowired
    private BookingsRepository bookingRepo;

    @Autowired
    private PaymentRepository paymentRepo;

    @Autowired
    private DriverRepository driverRepo;

    @Autowired
    private CustomerRepository customerRepo;

    @Autowired
    private VechileRepository vehicleRepo;

    // DRIVER RESPONSE (Accept/Reject)
    @Transactional
    public ResponseStructure<String> respondToBooking(int bookingId, boolean accepted) {
        Bookings booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found: " + bookingId));

        if (booking.getStatus() != BookingStatus.PENDING_APPROVAL) {
            throw new RuntimeException("Booking is not pending approval.");
        }

        if (accepted) {
            booking.setStatus(BookingStatus.CONFIRMED);

            // Generate 4-digit OTP
            String otp = String.format("%04d", new java.util.Random().nextInt(10000));
            booking.setOtp(otp);

            bookingRepo.save(booking);

            // Reset Rejection Count on success
            Driver driver = booking.getDriver();
            if (driver.getRejectionCount() > 0) {
                driver.setRejectionCount(0);
                driverRepo.save(driver);
            }

            ResponseStructure<String> rs = new ResponseStructure<>();
            rs.setStatusCode(HttpStatus.OK.value());
            rs.setMessage("Ride Accepted");
            rs.setData("Ride is now CONFIRMED. OTP Generated.");
            return rs;
        } else {
            // REJECTED
            booking.setStatus(BookingStatus.REJECTED);

            // CANCEL PAYMENT
            if (booking.getPayment() != null) {
                booking.getPayment().setPaymentStatus(PaymentStatus.CANCELLED);
                paymentRepo.save(booking.getPayment());
            }

            Driver driver = booking.getDriver();
            Vechile vehicle = driver.getV();

            // Increment Rejection Count
            int newCount = driver.getRejectionCount() + 1;
            driver.setRejectionCount(newCount);

            String message = "Ride Rejected";

            if (newCount >= 5) {
                // BLOCK DRIVER
                driver.setBlockedUntil(LocalDateTime.now().plusHours(24));
                driver.setStatus("Blocked");
                vehicle.setAvailablestatus("Blocked");
                message = "Driver Blocked for 24 Hours due to 5 consecutive rejections.";
            } else {
                // Normal Rejection - Free up resources
                driver.setStatus("Available");
                vehicle.setAvailablestatus("Available");
            }

            driverRepo.save(driver);
            vehicleRepo.save(vehicle);
            bookingRepo.save(booking);

            ResponseStructure<String> rs = new ResponseStructure<>();
            rs.setStatusCode(HttpStatus.OK.value());
            rs.setMessage("Ride Rejected");
            rs.setData(message);
            return rs;
        }
    }

    @Autowired
    private MapService mapService;
    @Autowired
    private RestTemplate restTemplate;


    // CREATE BOOKING
    @Transactional
    public ResponseStructure<BookingResponseDTO> createBooking(BookingRequestDTO request) {

        // STEP 1: VALIDATE CUSTOMER (Fast, no lock needed)
        Customer customer = customerRepo.findById(request.getCustomerId())
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        // STEP 2: CHECK FOR ACTIVE BOOKING (Prevent double-click duplicate bookings)
        Optional<Bookings> existingBooking = bookingRepo.findActiveBookingByCustomer(customer.getMobileno());
        if (existingBooking.isPresent()) {
            throw new RuntimeException("You already have an active booking. Please complete or cancel it first.");
        }

        // STEP 3: CALCULATE DISTANCE & FARE (Slow external API - do BEFORE locking!)
        double distance = 0.0;
        double pricePerKm = 0.0;

        // First, peek at vehicle to get price (non-locking read)
        Vechile vehiclePeek = vehicleRepo.findById(request.getVehicleId())
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));
        pricePerKm = vehiclePeek.getPriceperkm();

        try {
            double[] src = mapService.getCoordinates(request.getSourceLocation());
            double[] dest = mapService.getCoordinates(request.getDestinationLocation());
            distance = mapService.getDistanceInKm(src[0], src[1], dest[0], dest[1]);
        } catch (Exception e) {
            throw new RuntimeException("Map Error: " + e.getMessage());
        }

        double fare = distance * pricePerKm;

        // APPLY PENALTY
        if (customer.getPenaltyAmount() != null && customer.getPenaltyAmount() > 0) {
            fare += customer.getPenaltyAmount();
        }

        // STEP 4: ACQUIRE LOCK & VALIDATE (Fast DB operation with lock)
        // Used pessimistic lock to prevent concurrent bookings
        Vechile vehicle = vehicleRepo.findByIdForUpdate(request.getVehicleId())
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));

        // Double-check availability after acquiring lock
        if (!"Available".equalsIgnoreCase(vehicle.getAvailablestatus())) {
            throw new RuntimeException("Vehicle is already booked.");
        }

        Driver driver = vehicle.getDriver();
        if (driver == null)
            throw new RuntimeException("No driver assigned to this vehicle");

        if (!"Available".equalsIgnoreCase(driver.getStatus())) {
            throw new RuntimeException("Driver is currently unavailable.");
        }

        

        // STEP 5: RESET PENALTY (if applicable)
        if (customer.getPenaltyAmount() != null && customer.getPenaltyAmount() > 0) {
            customer.setPenaltyAmount(0.0);
            customer.setCancelCount(0);
            customerRepo.save(customer);
        }

        int speed = (vehicle.getAveragespeed() > 0) ? vehicle.getAveragespeed() : 40;
        int timeMinutes = (int) ((distance / speed) * 60);

        // STEP 6: CREATE BOOKING (Now holding lock - fast operation)
        Bookings booking = new Bookings();
        booking.setCust(customer);
        booking.setDriver(driver);
        booking.setSourecLocation(request.getSourceLocation());
        booking.setDestinationLocation(request.getDestinationLocation());
        booking.setDistanceTravelled(Math.round(distance * 100.0) / 100.0);
        booking.setFare(Math.round(fare * 100.0) / 100.0);
        booking.setEstimationTravelTime(timeMinutes + " mins");
        booking.setStatus(BookingStatus.PENDING_APPROVAL);
        booking.setBookingDate(LocalDateTime.now());

        // UPDATE JAVA LISTS
        if (customer.getBookinglist() != null)
            customer.getBookinglist().add(booking);
        if (driver.getBookinglist() != null)
            driver.getBookinglist().add(booking);

        // SAVE BOOKING
        Bookings savedBooking = bookingRepo.save(booking);

        // CREATE PAYMENT
        Payment payment = new Payment();
        payment.setBooking(savedBooking);
        payment.setAmount(savedBooking.getFare());
        payment.setPaymentType(request.getPaymentMethod());
        payment.setPaymentStatus(PaymentStatus.PENDING);
        payment.setPaymentTime(LocalDateTime.now());

        paymentRepo.save(payment);

        // LOCK BOTH VEHICLE AND DRIVER
        vehicle.setAvailablestatus("Booked");
        vehicleRepo.save(vehicle);

        driver.setStatus("On Trip");
        driverRepo.save(driver);

        // RESPONSE
        BookingResponseDTO responseDTO = new BookingResponseDTO(
                savedBooking.getId(),
                savedBooking.getFare(),
                savedBooking.getDistanceTravelled(),
                savedBooking.getEstimationTravelTime(),
                savedBooking.getStatus(),
                payment.getPaymentStatus(),
                driver.getName(),
                vehicle.getModel(),
                vehicle.getVno(),
                savedBooking.getBookingDate(),
                savedBooking.getSourecLocation(),
                savedBooking.getDestinationLocation());

        ResponseStructure<BookingResponseDTO> rs = new ResponseStructure<>();
        rs.setStatusCode(HttpStatus.CREATED.value());
        rs.setMessage("Waiting for Driver Approval");
        rs.setData(responseDTO);

        return rs;
    }

    // COMPLETE BOOKING
    @Transactional
    public ResponseStructure<String> completeRide(int bookingId) {
        Bookings booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found with ID: " + bookingId));

        if (booking.getStatus() == BookingStatus.COMPLETED) {
            throw new RuntimeException("Ride is already completed.");
        }

        booking.setStatus(BookingStatus.COMPLETED);

        Payment payment = paymentRepo.findByBooking(booking);
        if (payment != null) {
            payment.setPaymentStatus(PaymentStatus.SUCCESS);
            paymentRepo.save(payment);
        }

        Driver driver = booking.getDriver();
        if (driver != null) {
            driver.setStatus("Available");
            driverRepo.save(driver);

            Vechile vehicle = driver.getV();
            if (vehicle != null) {
                vehicle.setAvailablestatus("Available");
                vehicleRepo.save(vehicle);
            }
        }

        bookingRepo.save(booking);

        ResponseStructure<String> rs = new ResponseStructure<>();
        rs.setStatusCode(HttpStatus.OK.value());
        rs.setMessage("Ride completed successfully. Driver is now available.");
        rs.setData("Booking ID: " + bookingId + " is CLOSED.");

        return rs;
    }

    // CANCEL BOOKING (Customer)
    @Transactional
    public ResponseStructure<String> cancelBooking(int bookingId) {
        Bookings booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if (booking.getStatus() == BookingStatus.COMPLETED || booking.getStatus() == BookingStatus.CANCELLED) {
            throw new RuntimeException("Ride already ended");
        }

        booking.setStatus(BookingStatus.CANCELLED);

        // CANCEL PAYMENT
        if (booking.getPayment() != null) {
            booking.getPayment().setPaymentStatus(PaymentStatus.CANCELLED);
            paymentRepo.save(booking.getPayment());
        }

        // Free Driver & Vehicle
        Driver driver = booking.getDriver();
        if (driver != null) {
            driver.setStatus("Available");
            if (driver.getV() != null) {
                driver.getV().setAvailablestatus("Available");
                vehicleRepo.save(driver.getV());
            }
            driverRepo.save(driver);
        }

        // Penalty Logic
        Customer customer = booking.getCust();
        int newCount = customer.getCancelCount() + 1;
        customer.setCancelCount(newCount);

        String msg = "Ride Cancelled.";

        // Progressive Penalty: 1 FREE cancellation, then 10% from 2nd onwards
        if (newCount > 1) {
            Double currentPenaltyBucket = customer.getPenaltyAmount() != null ? customer.getPenaltyAmount() : 0.0;

            // Calculate 10% of the CANCELLED RIDE'S fare
            double penaltyForThisRide = booking.getFare() * 0.10;

            // Add to bucket
            customer.setPenaltyAmount(currentPenaltyBucket + penaltyForThisRide);

            msg += String.format(" Penalty Applied: ₹%.2f (10%% of fare). Total Penalty Pending: ₹%.2f",
                    penaltyForThisRide, customer.getPenaltyAmount());
        } else {
            msg += " This is your 1 FREE cancellation. Future cancellations will incur a 10% penalty.";
        }

        customerRepo.save(customer);
        bookingRepo.save(booking);

        ResponseStructure<String> rs = new ResponseStructure<>();
        rs.setStatusCode(HttpStatus.OK.value());
        rs.setMessage("Cancellation Successful");
        rs.setData(msg);
        return rs;
    }

    // VERIFY OTP (Start Ride)
    @Transactional
    public ResponseStructure<String> verifyOtp(int bookingId, String otp) {
        Bookings booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if (booking.getStatus() != BookingStatus.CONFIRMED) {
            throw new RuntimeException("Invalid Booking Status. Expecting CONFIRMED.");
        }

        if (booking.getOtp() != null && booking.getOtp().equals(otp)) {
            booking.setStatus(BookingStatus.IN_TRIP);
            bookingRepo.save(booking);

            ResponseStructure<String> rs = new ResponseStructure<>();
            rs.setStatusCode(HttpStatus.OK.value());
            rs.setMessage("OTP Verified");
            rs.setData("Ride Started (IN_TRIP)");
            return rs;
        } else {
            throw new RuntimeException("Invalid OTP");
        }
    }

    // BOOKING HISTORY OF CUSTOMER
    public ResponseStructure<List<BookingResponseDTO>> getBookingHistoryByCustomer(long mobileNo) {

        // Check if customer exists
        Customer cust = customerRepo.findByMobileno(mobileNo);
        if (cust == null)
            throw new RuntimeException("Customer not found");

        // Use optimized query with fetch joins (prevents N+1 query problem)
        List<Bookings> history = bookingRepo.findBookingHistoryByCustomer(mobileNo);

        List<BookingResponseDTO> historyDTOs = new ArrayList<>();

        for (Bookings b : history) {

            PaymentStatus pStatus = b.getPayment().getPaymentStatus();

            historyDTOs.add(new BookingResponseDTO(
                    b.getId(), b.getFare(), b.getDistanceTravelled(),
                    b.getEstimationTravelTime(), b.getStatus(),
                    pStatus,
                    b.getDriver().getName(),
                    b.getDriver().getV().getModel(),
                    b.getDriver().getV().getVno(),
                    b.getBookingDate(),
                    b.getSourecLocation(),
                    b.getDestinationLocation()));
        }

        ResponseStructure<List<BookingResponseDTO>> rs = new ResponseStructure<>();
        rs.setStatusCode(HttpStatus.OK.value());
        rs.setMessage("Booking History Fetched");
        rs.setData(historyDTOs);
        return rs;
    }

    // BOOKING HISTORY OF DRIVER
    public ResponseStructure<List<BookingResponseDTO>> getBookingHistoryByDriver(long mobileNo) {

        Driver driver = driverRepo.findBymobno(mobileNo);
        if (driver == null)
            throw new RuntimeException("Driver not found");

        // Use optimized query with fetch joins (prevents N+1 query problem)
        List<Bookings> history = bookingRepo.findBookingHistoryByDriver(mobileNo);

        List<BookingResponseDTO> historyDTOs = new ArrayList<>();
        for (Bookings b : history) {
            historyDTOs.add(new BookingResponseDTO(
                    b.getId(), b.getFare(), b.getDistanceTravelled(),
                    b.getEstimationTravelTime(), b.getStatus(),
                    b.getPayment().getPaymentStatus(),
                    b.getCust().getName(),
                    b.getDriver().getV().getModel(),
                    b.getDriver().getV().getVno(),
                    b.getBookingDate(),
                    b.getSourecLocation(),
                    b.getDestinationLocation()));
        }

        ResponseStructure<List<BookingResponseDTO>> rs = new ResponseStructure<>();
        rs.setStatusCode(HttpStatus.OK.value());
        rs.setMessage("Driver Ride History Fetched");
        rs.setData(historyDTOs);
        return rs;
    }

    // customer status
    public ResponseStructure<CustomerStatusDTO> checkCustomerStatus(long mobileNo) {

        // 1. First, find the customer
        Customer customer = customerRepo.findByMobileno(mobileNo);

        if (customer == null) {
            throw new CustomerNotFoundWithMobile("No Customer foun with " + mobileNo);
        }

        Optional<Bookings> activeRideOpt = bookingRepo.findActiveBookingByCustomer(mobileNo);

        // 3. Prepare the Response DTO
        CustomerStatusDTO statusDTO = new CustomerStatusDTO();
        statusDTO.setName(customer.getName());
        statusDTO.setMobileNo(customer.getMobileno());
        statusDTO.setCurrentLocation(customer.getCurrentLoc());

        // 4. Attach Booking Info ONLY if it exists
        if (activeRideOpt.isPresent()) {
            Bookings ride = activeRideOpt.get();
            statusDTO.setActiveBooking(new ActiveBookingDTO(
                    ride.getId(),
                    ride.getCust().getName(),
                    ride.getCust().getMobileno(),
                    ride.getSourecLocation(),
                    ride.getDestinationLocation(),
                    ride.getDriver().getName(),
                    ride.getDriver().getV().getVno(),
                    ride.getStatus().toString(),
                    ride.getFare(),
                    ride.getPayment().getPaymentType(),
                    ride.getOtp()));
        } else {
            statusDTO.setActiveBooking(null);

            // Check for Rejected Ride to notify user
            Optional<Bookings> lastOpt = bookingRepo.findTopByCust_MobilenoOrderByBookingDateDesc(mobileNo);
            if (lastOpt.isPresent()) {
                Bookings last = lastOpt.get();
                if (last.getStatus() == BookingStatus.REJECTED) {
                    statusDTO.setRecentBooking(new ActiveBookingDTO(
                            last.getId(),
                            last.getCust().getName(),
                            last.getCust().getMobileno(),
                            last.getSourecLocation(),
                            last.getDestinationLocation(),
                            last.getDriver().getName(),
                            last.getDriver().getV().getVno(),
                            last.getStatus().toString(),
                            last.getFare(),
                            last.getPayment().getPaymentType(),
                            last.getOtp()));
                }
            }
        }

        // 5. Send Success Response
        ResponseStructure<CustomerStatusDTO> rs = new ResponseStructure<>();
        rs.setStatusCode(HttpStatus.OK.value());
        rs.setMessage("Customer status fetched successfully");
        rs.setData(statusDTO);

        return rs;
    }

    public ResponseStructure<DriverStatusDTO> checkDriverStatus(long mobileNo) {

        // 1. Find Driver
        Driver driver = driverRepo.findBymobno(mobileNo);
        if (driver == null) {
            throw new DriverNOtFoundWiththismobileNO("Driver not found");
        }

        // 2. Check for Active Ride
        Optional<Bookings> activeRideOpt = bookingRepo.findActiveBookingByDriver(mobileNo);

        // 3. EFFICIENT CALCULATION via DB
        Double totalEarnings = bookingRepo.calculateDriverEarnings(mobileNo);
        Integer totalRides = bookingRepo.countDriverCompletedRides(mobileNo);

        DriverStatusDTO dto = new DriverStatusDTO();
        dto.setDriverId(driver.getId());
        dto.setName(driver.getName());
        dto.setEarnings(totalEarnings);
        dto.setTotalRides(totalRides != null ? totalRides : 0);
        dto.setVechileno(driver.getV().getVno());

        if (activeRideOpt.isPresent()) {
            Bookings ride = activeRideOpt.get();

            dto.setCurrentRide(new ActiveBookingDTO(
                    ride.getId(),
                    ride.getCust().getName(),
                    ride.getCust().getMobileno(),
                    ride.getSourecLocation(),
                    ride.getDestinationLocation(),
                    driver.getName(),
                    driver.getV().getVno(),
                    ride.getStatus().toString(),
                    ride.getFare(),
                    ride.getPayment().getPaymentType(),
                    null));
        } else {
            dto.setCurrentRide(null);
        }

        ResponseStructure<DriverStatusDTO> rs = new ResponseStructure<>();
        rs.setStatusCode(HttpStatus.OK.value());
        rs.setMessage("Driver status fetched");
        rs.setData(dto);
        return rs;
    }

    // GENERATE UPI QR CODE
    public ResponseStructure<UpiPaymentDTO> generateUpiQr(int bookingId) {

        // 1. Fetch Booking
        Bookings booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found: " + bookingId));

        // 2. Get Details
        Driver driver = booking.getDriver();
        if (driver == null)
            throw new RuntimeException("Driver details missing.");

        String upiId = driver.getUpiid();
        if (upiId == null || upiId.isEmpty()) {
            throw new RuntimeException("Driver does not have a UPI ID linked.");
        }

        double amount = booking.getFare();
        String name = driver.getName();

        // 3. Construct API URL
        String upiString = "upi://pay?pa=" + upiId + "&pn=" + name + "&am=" + amount;

        // QR Server API:
        String qrApiUrl = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" + upiString;

        // 4. Call API
        byte[] imageBytes = restTemplate.getForObject(qrApiUrl, byte[].class);

        // 5. Prepare DTO
        UpiPaymentDTO dto = new UpiPaymentDTO(bookingId, amount, upiId, name, imageBytes);

        ResponseStructure<UpiPaymentDTO> rs = new ResponseStructure<>();
        rs.setStatusCode(HttpStatus.OK.value());
        rs.setMessage("QR Code Generated Successfully");
        rs.setData(dto);

        return rs;
    }
}