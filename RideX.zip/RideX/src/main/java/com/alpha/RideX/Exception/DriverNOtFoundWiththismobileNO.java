package com.alpha.RideX.Exception;

public class DriverNOtFoundWiththismobileNO extends RuntimeException {
	
	
	public DriverNOtFoundWiththismobileNO(String message) {
        super(message);
    }
	
}
