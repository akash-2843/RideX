package com.alpha.RideX.Entity;

public enum PaymentType {
	CASH,
    UPI,
    CREDIT_CARD,
    DEBIT_CARD,
    WALLET
}
