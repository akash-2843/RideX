package com.alpha.RideX.Configuration;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
public class JwtUtil {

    // JWT Secret Key - loaded from application.properties for security
    @Value("${jwt.secret.key}")
    private String SECRET_KEY;

    // Token expiration time in milliseconds (default: 24 hours)
    @Value("${jwt.expiration.ms}")
    private long EXPIRATION_TIME;

    // Extract Username (which is Mobile Number in our case) from the token
    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    // Generic method to extract any specific piece of data (Claim) from the token
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    // Parse the token to read all the data inside it
    private Claims extractAllClaims(String token) {
        return Jwts
                .parserBuilder()
                .setSigningKey(getSignInKey()) // Use our secret key to unlock/verify
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    // Helper to decode our SECRET_KEY into a format Java security understands
    private Key getSignInKey() {
        byte[] keyBytes = Decoders.BASE64.decode(SECRET_KEY);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    // GENERATE TOKEN LOGIC

    // Main method called when User logs in successfully
    public String generateToken(UserDetails userDetails) {
        return generateToken(new HashMap<>(), userDetails);
    }

    public String generateToken(Map<String, Object> extraClaims, UserDetails userDetails) {
        return Jwts
                .builder()
                .setClaims(extraClaims) // Add any extra info (like Role) here if needed
                .setSubject(userDetails.getUsername()) // Set the "Who" (Mobile Number)
                .setIssuedAt(new Date(System.currentTimeMillis())) // "Time of Stamping"
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME)) // Loaded from config
                .signWith(getSignInKey(), SignatureAlgorithm.HS256) // Sign it with our Secret Key
                .compact(); // Pack it into a string
    }

    // VALIDATION LOGIC

    // Check if the token belongs to the given user and is not expired
    public boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        // 1. Check if token username matches the actual user
        // 2. Check if token expiration date is not in the past
        return (username.equals(userDetails.getUsername())) && !isTokenExpired(token);
    }

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }
}
