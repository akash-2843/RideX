package com.alpha.RideX.DTO;

import jakarta.validation.constraints.*;

public class BookingRequestDTO {

    @Min(value = 1, message = "Customer ID is required")
    private int customerId;

    @Min(value = 1, message = "Vehicle ID is required")
    private int vehicleId;

    @NotBlank(message = "Source location is required")
    @Size(min = 2, max = 200, message = "Source location must be between 2 and 200 characters")
    private String sourceLocation;

    @NotBlank(message = "Destination location is required")
    @Size(min = 2, max = 200, message = "Destination location must be between 2 and 200 characters")
    private String destinationLocation;

    @NotBlank(message = "Payment method is required")
    @Pattern(regexp = "^(CASH|UPI)$", message = "Payment method must be CASH or UPI")
    private String paymentMethod;

    public BookingRequestDTO() {
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getSourceLocation() {
        return sourceLocation;
    }

    public void setSourceLocation(String sourceLocation) {
        this.sourceLocation = sourceLocation;
    }

    public String getDestinationLocation() {
        return destinationLocation;
    }

    public void setDestinationLocation(String destinationLocation) {
        this.destinationLocation = destinationLocation;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
}