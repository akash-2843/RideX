package com.alpha.RideX.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.alpha.RideX.ResponseStructure;
import com.alpha.RideX.Service.LocationService;

@RestController
@RequestMapping("/api/location")
@CrossOrigin
public class LocationController {

    @Autowired
    private LocationService locationService;

    
    @GetMapping("/reverse")
    public ResponseEntity<ResponseStructure<String>> getCityFromCoordinates(
            @RequestParam double lat,
            @RequestParam double lng) {

        String city = locationService.getCityFromCoordinates(lat, lng);

        ResponseStructure<String> response = new ResponseStructure<>();
        response.setStatusCode(200);
        response.setMessage("Location detected successfully");
        response.setData(city);

        return ResponseEntity.ok(response);
    }
}
