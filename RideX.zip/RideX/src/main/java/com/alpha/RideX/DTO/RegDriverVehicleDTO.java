package com.alpha.RideX.DTO;

import jakarta.validation.constraints.*;

public class RegDriverVehicleDTO {

	// Driver Personal Details
	@NotBlank(message = "Name is required")
	@Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
	private String name;

	@Min(value = 18, message = "Age must be at least 18")
	@Max(value = 70, message = "Age must be less than 70")
	private int age;

	@NotBlank(message = "Gender is required")
	@Pattern(regexp = "^(Male|Female|Other)$", message = "Gender must be Male, Female, or Other")
	private String gender;

	@Min(value = 1000000000L, message = "Mobile number must be 10 digits")
	@Max(value = 9999999999L, message = "Mobile number must be 10 digits")
	private long mobileNo;

	@NotBlank(message = "Email is required")
	@Email(message = "Invalid email format")
	private String mail;

	@NotBlank(message = "Password is required")
	@Size(min = 6, max = 50, message = "Password must be between 6 and 50 characters")
	private String password;

	@NotBlank(message = "License number is required")
	@Size(min = 5, max = 20, message = "License number must be between 5 and 20 characters")
	private String licenceNo;

	@NotBlank(message = "UPI ID is required")
	@Pattern(regexp = "^[a-zA-Z0-9.\\-_]+@[a-zA-Z]+$", message = "Invalid UPI ID format (e.g., name@upi)")
	private String upiId;

	// Vehicle Details
	@NotBlank(message = "Vehicle name is required")
	@Size(min = 2, max = 50, message = "Vehicle name must be between 2 and 50 characters")
	private String vehicleName;

	@NotBlank(message = "Vehicle number is required")
	@Pattern(regexp = "^[A-Z]{2}[-\\s]?\\d{1,2}[-\\s]?[A-Z]{1,2}[-\\s]?\\d{1,4}$", message = "Invalid vehicle number format (e.g., KA-01-AB-1234)")
	private String vehicleNo;

	@NotBlank(message = "Vehicle type is required")
	@Pattern(regexp = "^(Sedan|SUV|Hatchback|Auto)$", message = "Vehicle type must be Sedan, SUV, Hatchback, or Auto")
	private String type;

	@NotBlank(message = "Model year is required")
	private String model;

	@Min(value = 1, message = "Capacity must be at least 1")
	@Max(value = 10, message = "Capacity cannot exceed 10")
	private int capacity;

	@NotNull(message = "Price per km is required")
	@DecimalMin(value = "1.0", message = "Price per km must be at least ₹1")
	@DecimalMax(value = "100.0", message = "Price per km cannot exceed ₹100")
	private Double pricePerKm;

	@Min(value = 10, message = "Average speed must be at least 10 km/h")
	@Max(value = 150, message = "Average speed cannot exceed 150 km/h")
	private int averageSpeed;

	// Location
	private Double longitude;
	private Double latitude;
	private String locationName;

	// Getters and Setters
	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getUpiId() {
		return upiId;
	}

	public void setUpiId(String upiId) {
		this.upiId = upiId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public String getVehicleNo() {
		return vehicleNo;
	}

	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getPricePerKm() {
		return pricePerKm;
	}

	public void setPricePerKm(Double pricePerKm) {
		this.pricePerKm = pricePerKm;
	}

	public int getAverageSpeed() {
		return averageSpeed;
	}

	public void setAverageSpeed(int averageSpeed) {
		this.averageSpeed = averageSpeed;
	}

	@Override
	public String toString() {
		return "RegDriverVehicleDTO [licenceNo=" + licenceNo + ", upiId=" + upiId + ", name=" + name + ", age=" + age
				+ ", mobileNo=" + mobileNo + ", gender=" + gender + ", mail=" + mail + ", vehicleName=" + vehicleName
				+ ", VehicleNo=" + vehicleNo + ", type=" + type + ", model=" + model + ", capacity=" + capacity
				+ ", longitude=" + longitude + ", latitude=" + latitude + ", pricePerKm=" + pricePerKm
				+ ", averageSpeed=" + averageSpeed + "]";
	}

}
