package com.alpha.RideX.Exception;

public class CustomerNotFoundWithMobile extends RuntimeException {

	public CustomerNotFoundWithMobile(String message)
	{
		super(message);
	}
}
