package com.alpha.RideX.DTO;

public class CustomerStatusDTO {

	private String name;
	private Long mobileNo;
	private String currentLocation;

	private ActiveBookingDTO activeBooking;
	private ActiveBookingDTO recentBooking;

	public CustomerStatusDTO() {
		super();
	}

	public CustomerStatusDTO(String name, Long mobileNo, String currentLocation, ActiveBookingDTO activeBooking) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.currentLocation = currentLocation;
		this.activeBooking = activeBooking;
	}

	// New constructor including recentBooking
	public CustomerStatusDTO(String name, Long mobileNo, String currentLocation, ActiveBookingDTO activeBooking,
			ActiveBookingDTO recentBooking) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.currentLocation = currentLocation;
		this.activeBooking = activeBooking;
		this.recentBooking = recentBooking;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public ActiveBookingDTO getActiveBooking() {
		return activeBooking;
	}

	public void setActiveBooking(ActiveBookingDTO activeBooking) {
		this.activeBooking = activeBooking;
	}

	public ActiveBookingDTO getRecentBooking() {
		return recentBooking;
	}

	public void setRecentBooking(ActiveBookingDTO recentBooking) {
		this.recentBooking = recentBooking;
	}

	@Override
	public String toString() {
		return "CustomerStatusDTO [name=" + name + ", mobileNo=" + mobileNo + ", currentLocation=" + currentLocation
				+ ", activeBooking=" + activeBooking + ", recentBooking=" + recentBooking + "]";
	}
}