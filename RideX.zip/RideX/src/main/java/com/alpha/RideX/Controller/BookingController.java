package com.alpha.RideX.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alpha.RideX.ResponseStructure;
import com.alpha.RideX.DTO.BookingRequestDTO;
import com.alpha.RideX.DTO.BookingResponseDTO;
import com.alpha.RideX.DTO.CustomerStatusDTO;
import com.alpha.RideX.DTO.DriverStatusDTO;
import com.alpha.RideX.DTO.UpiPaymentDTO;
import com.alpha.RideX.Service.BookingService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // Book a Ride
    @PostMapping("/book")
    public ResponseEntity<ResponseStructure<BookingResponseDTO>> bookRide(
            @Valid @RequestBody BookingRequestDTO request) {

        ResponseStructure<BookingResponseDTO> response = bookingService.createBooking(request);

        return ResponseEntity
                .status(response.getStatusCode())
                .body(response);
    }

    // Cancel Booking
    @PostMapping("/cancel")
    public ResponseEntity<ResponseStructure<String>> cancelBooking(@RequestParam int bookingId) {
        ResponseStructure<String> response = bookingService.cancelBooking(bookingId);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    // Otp Verification
    @PostMapping("/verify-otp")
    public ResponseEntity<ResponseStructure<String>> verifyOtp(@RequestParam int bookingId, @RequestParam String otp) {
        ResponseStructure<String> response = bookingService.verifyOtp(bookingId, otp);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    // Booking Response
    @PostMapping("/respond")
    public ResponseEntity<ResponseStructure<String>> respondToBooking(@RequestParam int bookingId,
            @RequestParam boolean accepted) {
        ResponseStructure<String> response = bookingService.respondToBooking(bookingId, accepted);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    // COMPELETE BOOKING
    @PostMapping("/completebooking")
    public ResponseEntity<ResponseStructure<String>> completeRide(@RequestParam int bookingId) {
        ResponseStructure<String> response = bookingService.completeRide(bookingId);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    // GENERATE UPI QR
    @GetMapping("/payment/upi")
    public ResponseEntity<ResponseStructure<UpiPaymentDTO>> generateQr(@RequestParam int bookingId) {
        ResponseStructure<UpiPaymentDTO> response = bookingService.generateUpiQr(bookingId);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    // CUSTOMER BOOKING HISTORY
    @GetMapping("/history/customer")
    public ResponseEntity<ResponseStructure<List<BookingResponseDTO>>> getCustomerHistory(@RequestParam long mobileNo) {
        ResponseStructure<List<BookingResponseDTO>> response = bookingService.getBookingHistoryByCustomer(mobileNo);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    // DRIVER BOOKING HISTORY
    @GetMapping("/history/driver")
    public ResponseEntity<ResponseStructure<List<BookingResponseDTO>>> getDriverHistory(@RequestParam long mobileNo) {
        ResponseStructure<List<BookingResponseDTO>> response = bookingService.getBookingHistoryByDriver(mobileNo);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    // Customer Status
    @GetMapping("/customer/status")
    public ResponseEntity<ResponseStructure<CustomerStatusDTO>> seeactivebooking(@RequestParam long mobileNo) {
        ResponseStructure<CustomerStatusDTO> response = bookingService.checkCustomerStatus(mobileNo);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @GetMapping("/driver/status")
    public ResponseStructure<DriverStatusDTO> checkDriverStatus(@RequestParam long mobileNo) {
        return bookingService.checkDriverStatus(mobileNo);
    }
}