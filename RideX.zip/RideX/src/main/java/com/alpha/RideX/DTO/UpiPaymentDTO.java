package com.alpha.RideX.DTO;

public class UpiPaymentDTO {

    private int bookingId;
    private double amount;
    private String upiId;
    private String driverName;
    private byte[] qrCodeImage;

    public UpiPaymentDTO() {
    }

    public UpiPaymentDTO(int bookingId, double amount, String upiId, String driverName, byte[] qrCodeImage) {
        this.bookingId = bookingId;
        this.amount = amount;
        this.upiId = upiId;
        this.driverName = driverName;
        this.qrCodeImage = qrCodeImage;
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getUpiId() {
        return upiId;
    }

    public void setUpiId(String upiId) {
        this.upiId = upiId;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public byte[] getQrCodeImage() {
        return qrCodeImage;
    }

    public void setQrCodeImage(byte[] qrCodeImage) {
        this.qrCodeImage = qrCodeImage;
    }
}
