package com.alpha.RideX.Exception;

public class VehiclesareNotavilabletoDestinationLocation extends RuntimeException {
     
	public VehiclesareNotavilabletoDestinationLocation(String message) {
        super(message);
    }
	
}
