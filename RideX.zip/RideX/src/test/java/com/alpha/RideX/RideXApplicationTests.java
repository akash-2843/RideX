package com.alpha.RideX;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RideXApplicationTests {

	@Test
	void contextLoads() {
	}

}
